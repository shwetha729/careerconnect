import requests
import sys
from requests.structures import CaseInsensitiveDict
import json


#convert delay into distance in meters
def delay2distance(delay, propspeed):
	#propagation = 95.63 #km/ms propagation factor
	propagation = float(propspeed)
	distance = ((delay/2) * propagation) * 1000 #convert RTT to OWD, multiply with p and convert to meters
	return distance

#get RTT with echo time removed
def getRTT(list1):
	#based on path latency: removes Dg = extra time elapsed to generate replies on hop
	sum = 0.0
	diff = 0.0
	length = len(list1) - 1
	if(length > 1):
		for i in range(length):
			diff = list1[i] - list1[-1]
			sum += diff
		dg = (1/(len(list1)-1))*sum
		rtt = list1[-1]+dg 
		#print("original: " + str(list1[-1]) + "|| new: " + str(rtt))
	else:
		return 0
	return rtt
	


list = []
outputs = []
allTimes = []
allDistances = []
nodeTimes = []
probes = []
probes_output =[]	

print("IP-Based Multilateration")
input_ID = sys.argv[1] #get measurement ID
propspeed = sys.argv[2] #enter propagation speed
inputID = int(input_ID) #concentate input ID into integer
param = {'id': inputID, 'type':'traceroute', 'format': 'json', 'optional_fields': 'probes'} #parameters for json request

#get measurements in json form
getMeasurement = requests.get('https://atlas.ripe.net:443/api/v2/measurements/',params=param) #json requeqst
initialResult = getMeasurement.json()['results'][0]['result']  #get results from json reply
targetIP = getMeasurement.json()['results'][0]['resolved_ips'][0] #target IP array

# parameters for finding latitude and longitude for target IP
parameter = {"fields":"49344"}
ipurl = "http://ip-api.com/json/" + targetIP #pull "theoretical" target IP location via IP-API
getLoc = requests.get(ipurl, params=parameter)
loc = getLoc.json()
latlong = [loc.get("lat",0), loc.get("lon",0)] 


results = requests.get(initialResult)
result = results.json()

for a in result:
	elements = a['result']
	id = a['prb_id']
	hops = len(a['result'])
	length = len(elements)
	#find minimum round trip times (0 means no response) for each probe
	for b in range(length):
		innerResult = elements[b]['result']
		rtt = innerResult[0].get('rtt',0)
		for c in range(len(innerResult)):
			timeone = innerResult[c].get('rtt',0)
			if(timeone != 0):
				if(timeone <= rtt):
					rtt = timeone
		if(rtt <= 25 and rtt != 0):
			nodeTimes.append(rtt)
	dgRTT = getRTT(nodeTimes) #get RTTs from minimum round trip times
	delays = [nodeTimes[-1], dgRTT]
	distances = [delay2distance(nodeTimes[-1], propspeed), delay2distance(dgRTT, propspeed)]
	allTimes.append(delays)
	allDistances.append(distances)
	probes.append(str(id)+","+str(hops)) #put into string
	nodeTimes = []
url = "https://atlas.ripe.net:443/api/v2/probes/?id__in=" #establish probe request from ripe api
for f in range(len(probes)):
	elements = probes[f].split(',')
	prbId = elements[0]
	res = requests.get(url + str(prbId))
	
	result = res.json()['results'][0]["geometry"]["coordinates"] #get longitude and latitudes from json requests
	probe_dict = {"prb_id": prbId, "latlong": [result[1], result[0]], "delay": allTimes[f], "distances": allDistances[f]}
	probes_output.append(probe_dict)

#append out
outputs.append({"targetIP": targetIP, "latlong": latlong, "probes": probes_output})


#compile all measurements into json
with open('measurements.json', 'w') as json_file:
	json.dump(outputs, json_file, indent=4)
print("Json compiled")
