<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}

print "<main>";
print "<h3>Topics</h3>";

$topic_id = $_REQUEST['topic_id'];
$post_query = "select * from posts where topic_id = ".$topic_id." order by create_time desc";
        $result = $conn->query($post_query);
if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc()){
        $user = getUserById($conn, $row['user_id']);
        print   $user['username']." - ". $row['title'] . " " . $row['create_time'] ." <br/>";
        print "<h4>Replies</h4>";
        $replies = getRepliesforPost($conn,$row['post_id']);
        print "Replies found: ".count($replies);
        print "<hr>";
        foreach($replies as &$reply)
        {
            print "Title: " . $reply['title']. "<br>";
            print "Body: " . $reply['body']. "<br>";
            $replyuser = getUserById($conn, $reply['user_id']);
            print "User: " . $replyuser['username'] . "<br><hr>";
        }
    }
}
else {
    print "No topics.";
}



include "templates\\footer.html";