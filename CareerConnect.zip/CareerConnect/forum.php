<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}

print "<main>";
print "<h3>Topics</h3>";

$sql_query = "select * from topics order by create_time desc";
        $result = $conn->query($sql_query);
if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc()){
        print $row['subj'] . " " . $row['create_time'] ." <a href='posts.php?topic_id=".$row['topic_id']."'>Posts</a><br/>";
    }
}
else {
    print "No topics.";
}



include "templates\\footer.html";