<?php

print password_hash('password',PASSWORD_DEFAULT);