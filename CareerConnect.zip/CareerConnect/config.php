<?php

session_start();

$host = "localhost"; /* Host name */
$user = "root"; /* User */
$password = "P@ssw0rd#123"; /* Password */
$dbname = "careerconnect"; /* Database name */

$conn = mysqli_connect($host, $user, $password,$dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

function getUserById($conn, $user_id){
  $user_query = "select * from users where user_id = " . $user_id;
  $result = $conn->query($user_query);
  if($result->num_rows > 0)
  {
    return $result->fetch_assoc();
  }

}

function getRepliesforPost($conn, $post_id){
  $replies = array();
  $query = "select * from replies where post_id = " . $post_id;
  $result = $conn->query($query);
  while($row = $result->fetch_assoc()){
    $a = array_push($replies, $row);
  }
  return $replies;
}