<?php

include "config.php";

if(isset($_POST['but_submit'])){

    $username = mysqli_real_escape_string($conn,$_POST['txt_username']);
    $password = mysqli_real_escape_string($conn,$_POST['txt_password']);

    if ($username != "" && $password != ""){

        $sql_query = "select username,password,firstname,lastname,email,permission from users where username='".$username."'";
        $result = mysqli_query($conn, $sql_query);

        if(mysqli_num_rows($result) > 0)
        {
            $row = mysqli_fetch_array($result);

            if(password_verify($password, $row['password']))
            {
                $_SESSION['username'] = $row['username'];
                $_SESSION['firstname'] = $row['firstname'];
                $_SESSION['lastname'] = $row['lastname'];
                $_SESSION['permission'] = $row['permission'];
                header('Location: index.php');
            }
            else {
                $error = "Invalid username or password.";
            }
        } 
        else {
            $error = "Invalid username or password.";
        }
    }
}

include "templates\\header.html";
include "templates\\navigation-default.html";
include "templates\\login.html";
include "templates\\footer.html";