<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}



print "<main>";
print "<h3>Profile</h3>";
print "<p>Information</p>";

include "templates\\footer.html";