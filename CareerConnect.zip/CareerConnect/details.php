<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}
$event_id = $_REQUEST['event_id'];

print "<main>";
print "<h3>Event Details</h3>";
//print "<h4>Beginning Time: ".$create_time."</h4>";



$query = "select * from attendees where event_id = ".$event_id;
        $result = $conn->query($query);


    print "<h4>Attendees</h4>";
    if($result->num_rows > 0)
    {
        while($row = $result->fetch_assoc()){
            
            $user = getUserById($conn, $row['user_id']);
            print   $user['username']." - ". $user['firstname'] . " " . $user['lastname'] ." <br/>";
        }
    }
    else {
        print "No attendees.";
    }



include "templates\\footer.html";