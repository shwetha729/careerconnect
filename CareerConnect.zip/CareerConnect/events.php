<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}

print "<main>";
print "<h3>Events</h3>";

$sql_query = "select * from events order by create_time desc";
        $result = $conn->query($sql_query);
if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc()){
        print $row['title'] . " " . $row['create_time'] ."<a href='details.php?event_id=".$row['event_id']."'>Event Details</a><br/>";
    }
}
else {
    print "No events.";
}

include "templates\\footer.html";